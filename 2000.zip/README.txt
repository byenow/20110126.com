A Pen created at CodePen.io. You can find this one at http://codepen.io/davidensinger/pen/YPNyea.

 An excuse to use countUp.js, Waypoints, Smooth Scroll, and Flexbox. See the source for further information :)

**JS**

- [countUp.js](http://inorganik.github.io/countUp.js/): a lightweight JavaScript "class" that can be used to quickly create animations that display numerical data in a more interesting way
- [Waypoints](http://imakewebthings.com/waypoints/): The easiest way to trigger a function when you scroll to an element
- [Smooth Scroll](https://github.com/cferdinandi/smooth-scroll): A lightweight script to animate scrolling to anchor links
- [forEach.js](https://github.com/toddmotto/foreach): A simple forEach() implementation for Arrays, Objects and NodeLists that takes away repetitive object lookups and array notations

**SVG**

- [SVGeneration](http://www.svgeneration.com/): Nice collection of SVG background images
- [SVG Editor](http://petercollingridge.appspot.com/svg-editor): Best in-browser tool for optimizing SVGs